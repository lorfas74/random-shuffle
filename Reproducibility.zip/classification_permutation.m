function [enhancedData] = classification_permutation(Data,sampleEnhancement)
if sampleEnhancement==0
    enhancedData = Data;
else
    %%
    feature_table = Data;
    class_column=feature_table(:,end);
    [class_name,ia,~]=unique(class_column,'stable');
    class_number=size(class_name,1);
    %%
    split_feature_table=cell(class_number,1);
    split_feature_table{1,1}=feature_table(ia(1,1):(ia(2,1)-1),:);
    for i=2:(class_number-1)
        split_feature_table{i,1}=feature_table(ia(i,1):(ia(i+1,1)-1),:);
    end
    split_feature_table{class_number,1}=feature_table(ia(class_number,1):end,:);
    %%
    split_feature_array=cell(class_number,1);
    for i=1:class_number
        split_feature_array{i,1}=table2array(split_feature_table{i,1}(:,1:(end-1)))';
    end
    %%
    feature_name=feature_table.Properties.VariableNames;
    feature_name=feature_name(1,1:(end-1));
    feature_number=size(feature_name,2);
    sample_number=NaN(class_number,1);
    split_feature_array_perm=cell(class_number,sampleEnhancement+1);
    rng('shuffle');
    for i=1:class_number
        split_feature_array_perm{i,1}=split_feature_array{i,1};
        for j=1:sampleEnhancement
            for k=1:feature_number
                sample_number(i,1)=size(split_feature_array{i,1},2);
                sample_random=randperm(sample_number(i,1));
                to_perm_row=split_feature_array{i,1}(k,:);
                perm_row=to_perm_row(sample_random);
                split_feature_array_perm{i,j+1}(k,:)=perm_row;
            end
        end
    end
    rng('default');
    %%
    feature_name=feature_table.Properties.VariableNames;
    for i=1:class_number
        for j=1:(sampleEnhancement+1)
            split_feature_array_perm{i,j}=split_feature_array_perm{i,j}';
            split_feature_table_perm{i,j}=array2table(split_feature_array_perm{i,j});
            split_feature_table_perm{i,j}(:,feature_number+1)=class_name(i,1);
            split_feature_table_perm{i,j}.Properties.VariableNames=feature_name;
        end
    end
    %%
    feature_table_new=split_feature_table_perm{1,1};
    feature_table_new.Properties.VariableNames=feature_name;
    feature_table_new(:,:)=[];
    for i=1:class_number
        for j=1:(sampleEnhancement+1)
            feature_table_new=[feature_table_new;split_feature_table_perm{i,j}];
        end
    end
    %%
    enhancedData = feature_table_new;
end
end