shuffle_original_data = readtable('stop_sco_aldo_dhf_preprocessed.xlsx','Range','A5:T390');
shuffle_original_data.class = categorical(shuffle_original_data.class);
%%
writetable(shuffle_original_data,'shuffle_original_data.xlsx');
shuffle_number = 49;
for i=1:shuffle_number
    [shuffled_data] = classification_permutation(shuffle_original_data,i);
    writetable(unique(shuffled_data,'stable','rows'),[num2str(i),'_shuffled_data.xlsx']);
end
clearvars;