preprocessed_data = readtable('19_shuffled_data.xlsx','Range','A1:T7236');
rra_original_data = [preprocessed_data(:,end) preprocessed_data(:,(end-6):(end-1))];
rra_original_data.Properties.VariableNames = {'class','meas1','meas2','meas3','meas4','meas5','meas6'};
rra_original_data.class = categorical(rra_original_data.class);
%%
meas = table([1 2 3 4 5 6]','VariableNames',{'measurements'});
rm = fitrm(rra_original_data,'meas1-meas6~class','WithinDesign',meas);
%%
rra_number = 10;
original_data_row_number = size(rm.BetweenDesign,1);
original_data_column_number = size(rm.BetweenDesign,2)-1;
preprocessed_data_column_number = size(preprocessed_data,2);
rra_data = table('Size',[((rra_number+1)*original_data_row_number) preprocessed_data_column_number],...
    'VariableTypes',{'double','double','double','double','double',...
    'double','double','double','double','double',...
    'double','double','double','double','double',...
    'double','double','double','double','categorical'},...
    'VariableNames',preprocessed_data.Properties.VariableNames);
group_column_number = preprocessed_data_column_number-original_data_column_number-1;
rra_data(1:original_data_row_number,:) = [preprocessed_data(:,1:group_column_number) rm.BetweenDesign(:,2:end) rm.BetweenDesign(:,1)];
writetable(rra_data(1:original_data_row_number,:),'rra_shuffled_original_data.xlsx');
for i=1:rra_number
    rra_data((i*original_data_row_number+1):((i+1)*original_data_row_number),:) =...
        [preprocessed_data(:,1:group_column_number) array2table(random(rm)) rm.BetweenDesign(:,1)];
    writetable(unique(rra_data(1:((i+1)*original_data_row_number),:),'stable','rows'),[num2str(i),'_rra_shuffled_data.xlsx']);
end
clearvars;