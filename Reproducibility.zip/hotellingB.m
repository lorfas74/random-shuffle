%%
addpath('HotellingT2');

rra_original_data=readtable('rra_original_data.xlsx');
shuffle_original_data=readtable('shuffle_original_data.xlsx');

%%
rra_data=readtable('37_rra_data.xlsx');
shuffled_data=readtable('1_rra_shuffled_data.xlsx');

%%
row_difference=size(rra_data,1)-size(shuffled_data,1);
X=[table2array(rra_data(1:end-row_difference,14:19));table2array(shuffled_data(:,14:19))];
Y=mean(rra_original_data{:,14:19},1)
T2Hot1(X,0.05);

%%
clear row_difference X Y;
save;