shuffleA;
rraA;