%%
addpath('HotellingT2');

rra_original_data=readtable('rra_original_data.xlsx');
shuffle_original_data=readtable('shuffle_original_data.xlsx');

%%
comparison_number=49;
rra_data=cell(comparison_number,1);
shuffled_data=cell(comparison_number,1);
for i=1:comparison_number
    rra_data{i,1}=readtable([num2str(i),'_rra_data.xlsx']);
    shuffled_data{i,1}=readtable([num2str(i),'_shuffled_data.xlsx']);
end

save;

%%
for i=1:comparison_number
    row_difference=size(rra_data{i,1},1)-size(shuffled_data{i,1},1);
    X=[table2array(rra_data{i,1}(1:end-row_difference,14:19));table2array(shuffled_data{i,1}(:,14:19))];
    display(['Comparison # ',num2str(i)])
    Y=mean(rra_original_data{:,14:19},1)
    T2Hot1(X,0.05);
end

%%
clear comparison_number i row_difference X Y;
save;